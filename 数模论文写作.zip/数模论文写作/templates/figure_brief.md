# Figure Brief

- figure_id:
- question:
- purpose:
- claim_to_support:
- data_source:
- x_axis:
- y_axis:
- groups_or_series:
- statistical_scope:
- comparison_baseline:
- uncertainty_to_show:
- required_annotations:
- preferred_layout:
- caption_key_message:

## 图前正文
说明：为什么需要这张图、要回答什么问题、统计口径是什么。

## 图后正文
说明：读图结果、量化证据、模型含义/下一步用途。
