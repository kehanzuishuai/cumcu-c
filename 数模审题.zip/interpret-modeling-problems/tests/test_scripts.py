from __future__ import annotations

import copy
import importlib.util
import json
import re
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


inventory = load_module("inventory_problem", SKILL_ROOT / "scripts" / "inventory_problem.py")
validator = load_module(
    "validate_interpretation", SKILL_ROOT / "scripts" / "validate_interpretation.py"
)


class ScriptTests(unittest.TestCase):
    def write_contract(self, directory: Path, name: str, contract: dict) -> Path:
        path = directory / name
        path.write_text(
            "```contract-json\n"
            + json.dumps(contract, ensure_ascii=False, indent=2)
            + "\n```\n",
            encoding="utf-8",
        )
        return path

    def test_inventory_reports_files_and_structure(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "records.csv").write_text("id,value\n1,2\n", encoding="utf-8")
            (root / "metadata.json").write_text('{"unit": "kg"}', encoding="utf-8")

            report = inventory.build_inventory(root)

            self.assertIn("records.csv", report)
            self.assertIn("表头=id, value", report)
            self.assertIn("metadata.json", report)
            self.assertIn("keys=unit", report)

    def test_validator_accepts_synthetic_report(self):
        report = SKILL_ROOT / "tests" / "fixtures" / "minimal_report.md"

        result = validator.inspect(report, expected_subproblems=1)

        self.assertTrue(result["pass"], result["errors"])
        self.assertEqual(result["detected_subproblems"], [1])
        self.assertEqual(result["placeholder_count"], 0)

    def test_anonymized_example_runs_end_to_end(self):
        example = SKILL_ROOT / "examples" / "anonymized-problem"
        report = example / "interpretation_final.md"

        result = validator.inspect(
            report,
            expected_subproblems=3,
            stage="final",
            ambiguities=example / "ambiguity_decisions.md",
            granularity_contract=example / "granularity_contract.md",
            hard_constraints=example / "hard_constraints.md",
            interpretation_decisions=example / "interpretation_decisions.md",
            model_assumptions=example / "model_assumptions.md",
            model_plan=example / "model_plan_final.md",
        )

        self.assertTrue(result["pass"], result["errors"])
        self.assertEqual(result["interpretation_status"], "PAPER_READY")
        self.assertEqual(result["detected_subproblems"], [1, 2, 3])
        self.assertEqual(result["placeholder_count"], 0)

        self.assertEqual(len(result["evidence_tags"]), 7)
        self.assertEqual(
            set(result["contract_checks"]["loaded_contracts"]),
            {
                "ambiguities",
                "granularity_contract",
                "hard_constraints",
                "interpretation_decisions",
                "model_assumptions",
                "model_plan",
            },
        )
        self.assertEqual(result["contract_checks"]["ambiguities"]["count"], 0)
        self.assertEqual(
            result["contract_checks"]["model_plan"]["granularity_conflicts"], []
        )
        self.assertEqual(
            result["contract_checks"]["model_plan"]["missing_hard_constraints"], []
        )
        self.assertEqual(result["contract_checks"]["model_assumptions"]["count"], 2)
        self.assertEqual(result["contract_checks"]["interpretation_decision_count"], 2)
        self.assertEqual(result["final_document_state"]["stale"], [])
        self.assertEqual(
            {Path(path).name for path in result["final_document_state"]["documents"]},
            {
                "interpretation_final.md",
                "ambiguity_decisions.md",
                "granularity_contract.md",
                "hard_constraints.md",
                "interpretation_decisions.md",
                "model_assumptions.md",
                "model_plan_final.md",
            },
        )
        self.assertTrue((example / "model_plan_final.md").is_file())
        self.assertFalse((example / "interpretation_draft.md").exists())

        draft = (example / "_archive" / "interpretation_draft.md").read_text(encoding="utf-8")
        self.assertIn("INTERPRETATION_PENDING", draft)

        inventory_report = inventory.build_inventory(example)
        self.assertIn("observations.csv", inventory_report)
        self.assertIn("zones.csv", inventory_report)
        self.assertIn("result_template.csv", inventory_report)

        audit = json.loads((example / "attachment_audit.json").read_text(encoding="utf-8"))
        self.assertEqual(audit["status"], "complete")
        self.assertEqual(len(audit["files"]), 3)
        self.assertTrue(all(item["audit_status"] == "verified" for item in audit["files"]))
        for item in audit["files"]:
            payload = (example / item["path"]).read_bytes().replace(b"\r\n", b"\n")
            self.assertEqual(len(payload), item["size_bytes"])

        acceptance = (example / "acceptance_report.md").read_text(encoding="utf-8")
        self.assertIn("得分率：100%", acceptance)
        self.assertIn("实得分：28", acceptance)
        self.assertIn("当前可评分项满分：28", acceptance)
        legacy_fixed_score = "20" + "/" + "20"
        self.assertNotIn(legacy_fixed_score, acceptance)

        readme = (SKILL_ROOT / "README.md").read_text(encoding="utf-8")
        self.assertIn("--stage final", readme)
        self.assertIn("--interpretation-decisions", readme)
        self.assertIn("--model-assumptions", readme)
        self.assertNotIn(legacy_fixed_score, readme)

    def test_skill_routes_are_single_problem_only(self):
        skill = (SKILL_ROOT / "SKILL.md").read_text(encoding="utf-8")
        readme = (SKILL_ROOT / "README.md").read_text(encoding="utf-8")
        output_schema = (SKILL_ROOT / "references" / "output-schema.md").read_text(
            encoding="utf-8"
        )

        route_section = skill.split("## 单题工作深度", 1)[1].split(
            "## 输入与独立性", 1
        )[0]
        self.assertEqual(
            re.findall(r"^- \*\*([^*]+)\*\*", route_section, flags=re.MULTILINE),
            ["full", "re-review", "paper-ready"],
        )
        self.assertIn("只处理题号已经确定的一道 C 题", skill)
        self.assertIn("只处理题号已经确定的一道 C 题", readme)
        self.assertIn("禁止读取任何 backup/archive 目录（包括 `_archive/`）", skill)
        self.assertTrue(output_schema.startswith("# 输出结构\n\n## 完整解读主报告"))
        self.assertTrue((SKILL_ROOT / "references" / "problem-type-guides.md").is_file())

    def test_release_fixture_paths_are_ascii_safe(self):
        for name in ("2024c-regression", "2023c-style-regression"):
            fixture = SKILL_ROOT / "tests" / "fixtures" / name
            for path in fixture.rglob("*"):
                relative = path.relative_to(SKILL_ROOT)
                with self.subTest(path=str(relative)):
                    str(relative).encode("ascii")

    def test_acceptance_rubric_uses_dynamic_score_rate(self):
        rubric = (SKILL_ROOT / "references" / "acceptance-rubric.md").read_text(
            encoding="utf-8"
        )

        self.assertIn("总得分率", rubric)
        self.assertIn("ceil(0.9 × 满分)", rubric)
        self.assertIn("所有 P0 项均为 `2` 分", rubric)
        self.assertNotIn("18/20", rubric)
        self.assertNotIn("按十项评分", rubric)

    def test_unique_high_evidence_must_be_resolved_without_user_confirmation(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"

        result = validator.inspect(
            fixture / "interpretation_final.md",
            expected_subproblems=3,
            stage="final",
            ambiguities=fixture / "ambiguity_resolved.md",
            granularity_contract=fixture / "granularity_contract.md",
            hard_constraints=fixture / "hard_constraints.md",
            interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            model_plan=fixture / "model_plan_valid_final.md",
            model_assumptions=fixture / "model_assumptions_empty.md",
        )

        self.assertTrue(result["pass"], result["errors"])
        self.assertEqual(result["interpretation_status"], "PAPER_READY")
        self.assertEqual(result["contract_checks"]["ambiguities"]["blocking"], [])
        self.assertEqual(result["contract_checks"]["model_assumptions"]["count"], 0)

        ambiguity = validator.extract_contract(
            fixture / "ambiguity_resolved.md", "ambiguity_decisions"
        )["items"][0]
        self.assertIn("data_granularity", ambiguity["impact"])
        self.assertEqual(ambiguity["evidence"][0]["value"], ["crop", "year", "season"])
        self.assertEqual(ambiguity["status"], "RESOLVED_BY_EVIDENCE")
        self.assertIsNone(ambiguity["approved_by"])

    def test_final_stage_requires_all_freeze_contracts(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"

        result = validator.inspect(
            fixture / "interpretation_final.md",
            expected_subproblems=3,
            stage="final",
        )

        self.assertFalse(result["pass"])
        self.assertEqual(result["interpretation_status"], "INTERPRETATION_PENDING")
        self.assertGreaterEqual(
            sum("missing contract" in error for error in result["errors"]), 6
        )

    def test_final_requires_interpretation_decisions_contract_even_when_empty(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"

        result = validator.inspect(
            fixture / "interpretation_final.md",
            expected_subproblems=3,
            stage="final",
            ambiguities=fixture / "ambiguity_resolved.md",
            granularity_contract=fixture / "granularity_contract.md",
            hard_constraints=fixture / "hard_constraints.md",
            model_plan=fixture / "model_plan_valid_final.md",
            model_assumptions=fixture / "model_assumptions_empty.md",
        )

        self.assertFalse(result["pass"])
        self.assertTrue(
            any("missing contract: interpretation_decisions" in error for error in result["errors"])
        )

    def test_final_requires_model_assumptions_contract_even_when_empty(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"

        result = validator.inspect(
            fixture / "interpretation_final.md",
            expected_subproblems=3,
            stage="final",
            ambiguities=fixture / "ambiguity_resolved.md",
            granularity_contract=fixture / "granularity_contract.md",
            hard_constraints=fixture / "hard_constraints.md",
            interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            model_plan=fixture / "model_plan_valid_final.md",
        )

        self.assertFalse(result["pass"])
        self.assertTrue(
            any("missing contract: model_assumptions" in error for error in result["errors"])
        )

    def test_2024c_explicit_each_season_evidence_cannot_be_overridden(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"

        result = validator.inspect(
            fixture / "interpretation_final.md",
            expected_subproblems=3,
            stage="final",
            ambiguities=fixture / "ambiguity_override.md",
            granularity_contract=fixture / "granularity_contract.md",
            hard_constraints=fixture / "hard_constraints.md",
            model_plan=fixture / "model_plan_valid_final.md",
            model_assumptions=fixture / "model_assumptions_empty.md",
            interpretation_decisions=fixture / "interpretation_decisions_empty.md",
        )

        self.assertFalse(result["pass"])
        self.assertIn(
            "sales_limit_period",
            result["contract_checks"]["ambiguities"]["evidence_overrides"],
        )
        self.assertTrue(any("P0 EVIDENCE_OVERRIDE" in error for error in result["errors"]))

    def test_2024c_evidence_resolved_each_season_contract_passes(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"

        result = validator.inspect(
            fixture / "interpretation_final.md",
            expected_subproblems=3,
            stage="final",
            ambiguities=fixture / "ambiguity_resolved.md",
            granularity_contract=fixture / "granularity_contract.md",
            hard_constraints=fixture / "hard_constraints.md",
            model_plan=fixture / "model_plan_valid_final.md",
            model_assumptions=fixture / "model_assumptions_empty.md",
            interpretation_decisions=fixture / "interpretation_decisions_empty.md",
        )

        self.assertTrue(result["pass"], result["errors"])
        self.assertEqual(result["interpretation_status"], "PAPER_READY")
        self.assertEqual(
            result["contract_checks"]["model_plan"]["granularity_conflicts"], []
        )

        ambiguity = validator.extract_contract(
            fixture / "ambiguity_resolved.md", "ambiguity_decisions"
        )["items"][0]
        sales_limit = validator.extract_contract(
            fixture / "granularity_contract.md", "granularity_contract"
        )["items"][1]
        model_plan = validator.extract_contract(
            fixture / "model_plan_valid_final.md", "model_plan"
        )["items"][1]
        self.assertEqual(ambiguity["decision"], ["crop", "year", "season"])
        self.assertEqual(sales_limit["dimensions"], ["crop", "year", "season"])
        self.assertEqual(model_plan["dimensions"], ["crop", "year", "season"])
        self.assertEqual(model_plan["symbol"], "D[c,t,s]")

    def test_resolved_ambiguity_with_stale_final_language_is_blocked_then_passes_when_cleaned(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        clean_report = (fixture / "interpretation_final.md").read_text(encoding="utf-8")
        clean_plan = (fixture / "model_plan_valid_final.md").read_text(encoding="utf-8")

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            report = root / "interpretation_final.md"
            plan = root / "model_plan_final.md"
            report.write_text(
                clean_report
                + "\nAMB-01 待确认；方案 A/B 待选；当前仍存在 BLOCKING；"
                + "仍并列保留 A/B 两种题意口径。\n",
                encoding="utf-8",
            )
            plan.write_text(clean_plan, encoding="utf-8")

            stale_result = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=plan,
            )

            self.assertFalse(stale_result["pass"])
            self.assertEqual(stale_result["interpretation_status"], "INTERPRETATION_PENDING")
            self.assertTrue(
                any("P0 STALE_DECISION_STATE" in error for error in stale_result["errors"])
            )
            markers = {
                item["marker"] for item in stale_result["final_document_state"]["stale"]
            }
            self.assertTrue(
                {
                    "待确认",
                    "BLOCKING",
                    "A/B_PENDING_SELECTION",
                    "RESOLVED_AMBIGUITY_OPTIONS",
                }.issubset(markers)
            )

            report.write_text(
                clean_report
                + "\n冻结摘要：BLOCKING=0，UNRESOLVED=0，无待确认项，待决定项=0，无待实现确认项。\n",
                encoding="utf-8",
            )
            clean_result = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=plan,
            )

            self.assertTrue(clean_result["pass"], clean_result["errors"])
            self.assertEqual(clean_result["interpretation_status"], "PAPER_READY")
            self.assertEqual(clean_result["final_document_state"]["stale"], [])

    def test_final_requires_top_level_draft_to_be_archived(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            report = root / "interpretation_final.md"
            plan = root / "model_plan_final.md"
            draft = root / "interpretation_draft.md"
            report.write_text(
                (fixture / "interpretation_final.md").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            plan.write_text(
                (fixture / "model_plan_valid_final.md").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            draft.write_text("# INTERPRETATION_PENDING\n", encoding="utf-8")

            blocked = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=plan,
            )
            self.assertFalse(blocked["pass"])
            self.assertTrue(
                any(
                    item["marker"] == "UNARCHIVED_DRAFT"
                    for item in blocked["final_document_state"]["stale"]
                )
            )

            archive = root / "_archive"
            archive.mkdir()
            draft.rename(archive / draft.name)
            passed = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=plan,
            )
            self.assertTrue(passed["pass"], passed["errors"])
            self.assertEqual(passed["interpretation_status"], "PAPER_READY")

    def test_stale_draft_language_in_any_markdown_contract_blocks_then_clean_passes(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            report = root / "interpretation_final.md"
            plan = root / "model_plan_final.md"
            hard = root / "hard_constraints.md"
            report.write_text(
                (fixture / "interpretation_final.md").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            plan.write_text(
                (fixture / "model_plan_valid_final.md").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            clean_hard = (fixture / "hard_constraints.md").read_text(encoding="utf-8")
            hard.write_text(
                clean_hard + "\n状态：DRAFT；当前为草稿；确认后升级；待冻结。\n",
                encoding="utf-8",
            )

            stale = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=hard,
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=plan,
            )
            markers = {item["marker"] for item in stale["final_document_state"]["stale"]}
            self.assertFalse(stale["pass"])
            self.assertTrue({"DRAFT", "草稿", "确认后升级", "待冻结"}.issubset(markers))
            self.assertTrue(any("STALE_DECISION_STATE" in error for error in stale["errors"]))
            self.assertIn(str(hard.resolve()), stale["final_document_state"]["documents"])

            hard.write_text(clean_hard, encoding="utf-8")
            clean = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=hard,
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=plan,
            )
            self.assertTrue(clean["pass"], clean["errors"])
            self.assertEqual(clean["interpretation_status"], "PAPER_READY")
            self.assertEqual(clean["final_document_state"]["stale"], [])

    def test_backup_directory_must_leave_handoff_but_archive_is_ignored(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            handoff = root / "handoff"
            handoff.mkdir()
            report = handoff / "interpretation_final.md"
            plan = handoff / "model_plan_final.md"
            report.write_text(
                (fixture / "interpretation_final.md").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            plan.write_text(
                (fixture / "model_plan_valid_final.md").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            backup = handoff / "history" / "draft_backup"
            backup.mkdir(parents=True)
            (backup / "old.md").write_text("# DRAFT\n", encoding="utf-8")

            blocked = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=plan,
            )
            self.assertFalse(blocked["pass"])
            self.assertTrue(
                any(
                    item["marker"] == "BACKUP_DIRECTORY_IN_HANDOFF"
                    for item in blocked["final_document_state"]["stale"]
                )
            )

            backup.rename(root / "draft_backup")
            archive = handoff / "_archive"
            archive.mkdir()
            (archive / "interpretation_draft.md").write_text(
                "# INTERPRETATION_PENDING DRAFT 草稿\n",
                encoding="utf-8",
            )
            passed = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=plan,
            )
            self.assertTrue(passed["pass"], passed["errors"])
            self.assertEqual(passed["interpretation_status"], "PAPER_READY")
            self.assertEqual(passed["final_document_state"]["stale"], [])

    def test_final_requires_regenerated_model_plan_filename(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            report = root / "interpretation_final.md"
            old_plan = root / "model_plan.md"
            report.write_text(
                (fixture / "interpretation_final.md").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            old_plan.write_text(
                (fixture / "model_plan_valid_final.md").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            result = validator.inspect(
                report,
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                model_plan=old_plan,
            )

        self.assertFalse(result["pass"])
        self.assertTrue(
            any(
                item["marker"] == "FINAL_NAME_REQUIRED"
                for item in result["final_document_state"]["stale"]
            )
        )
        self.assertTrue(any("STALE_DECISION_STATE" in error for error in result["errors"]))

    def test_2024c_cross_season_sales_limit_triggers_p0_conflict(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"

        result = validator.inspect(
            fixture / "interpretation_final.md",
            expected_subproblems=3,
            stage="final",
            ambiguities=fixture / "ambiguity_resolved.md",
            granularity_contract=fixture / "granularity_contract.md",
            hard_constraints=fixture / "hard_constraints.md",
            model_plan=fixture / "model_plan_conflict_final.md",
            model_assumptions=fixture / "model_assumptions_empty.md",
            interpretation_decisions=fixture / "interpretation_decisions_empty.md",
        )

        self.assertFalse(result["pass"])
        self.assertIn(
            "sales_limit",
            result["contract_checks"]["model_plan"]["granularity_conflicts"],
        )
        self.assertTrue(any("P0 GRANULARITY_CONFLICT" in error for error in result["errors"]))

    def test_2023c_style_modeling_choices_and_mixed_roles_reach_paper_ready(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2023c-style-regression"

        result = validator.inspect(
            fixture / "interpretation_final.md",
            expected_subproblems=4,
            stage="final",
            ambiguities=fixture / "ambiguity_empty.md",
            granularity_contract=fixture / "granularity_contract.md",
            hard_constraints=fixture / "hard_constraints.md",
            interpretation_decisions=fixture / "interpretation_decisions.md",
            model_assumptions=fixture / "model_assumptions.md",
            model_plan=fixture / "model_plan_valid_final.md",
        )

        self.assertTrue(result["pass"], result["errors"])
        self.assertEqual(result["interpretation_status"], "PAPER_READY")
        self.assertEqual(result["contract_checks"]["ambiguities"]["count"], 0)
        self.assertEqual(result["contract_checks"]["interpretation_decision_count"], 2)
        self.assertEqual(
            result["contract_checks"]["model_plan"]["granularity_semantic_conflicts"], []
        )

    def test_modeling_choice_misclassified_as_ambiguity_is_rejected(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2023c-style-regression"
        contract = {
            "contract_type": "ambiguity_decisions",
            "schema_version": 1,
            "items": [
                {
                    "id": "profit_formula_choice",
                    "kind": "interpretation_ambiguity",
                    "ambiguity_scope": "model_implementation",
                    "question": "收益采用线性还是分段核算？",
                    "impact": ["feasible_region", "result"],
                    "evidence": [
                        {
                            "level": "testable_assumption",
                            "value": "piecewise_profit",
                            "source": "数学实现选择；题面未指定公式形式",
                        }
                    ],
                    "options": [],
                    "recommended": "piecewise_profit",
                    "decision": None,
                    "approved_by": None,
                    "status": "BLOCKING",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            ambiguity = self.write_contract(Path(directory), "ambiguity.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=4,
                stage="final",
                ambiguities=ambiguity,
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions.md",
                model_assumptions=fixture / "model_assumptions.md",
                model_plan=fixture / "model_plan_valid_final.md",
            )

        self.assertFalse(result["pass"])
        self.assertTrue(
            any("P0 MISCLASSIFIED_MODELING_CHOICE" in error for error in result["errors"])
        )

    def test_downstream_impact_alone_does_not_classify_an_ambiguity(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2023c-style-regression"
        contract = {
            "contract_type": "ambiguity_decisions",
            "schema_version": 1,
            "items": [
                {
                    "id": "objective_meaning",
                    "kind": "interpretation_ambiguity",
                    "ambiguity_scope": "objective_definition",
                    "question": "题目中的收益是否包含处置成本？",
                    "impact": ["feasible_region", "result"],
                    "evidence": [
                        {
                            "level": "main_interpretation",
                            "value": "net_profit_with_disposal",
                            "source": "题面收益描述未明确处置成本归属",
                        },
                        {
                            "level": "alternative_interpretation",
                            "value": "net_profit_without_disposal",
                            "source": "附件另列处置费用但未说明是否计入目标",
                        },
                    ],
                    "options": [],
                    "recommended": "net_profit_with_disposal",
                    "decision": None,
                    "approved_by": None,
                    "freeze_targets": [],
                    "status": "BLOCKING",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            ambiguity = self.write_contract(Path(directory), "ambiguity.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=4,
                stage="draft",
                ambiguities=ambiguity,
            )

        self.assertTrue(result["pass"], result["errors"])
        self.assertFalse(
            any("MISCLASSIFIED_MODELING_CHOICE" in error for error in result["errors"])
        )
        self.assertEqual(result["contract_checks"]["ambiguities"]["blocking"], ["objective_meaning"])

    def test_granularity_semantic_role_must_match_model_plan(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2023c-style-regression"
        plan = validator.extract_contract(fixture / "model_plan_valid_final.md", "model_plan")
        plan = copy.deepcopy(plan)
        plan["items"][0]["semantic_role"] = "decision"
        with tempfile.TemporaryDirectory() as directory:
            plan_path = self.write_contract(Path(directory), "plan_final.md", plan)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=4,
                stage="final",
                ambiguities=fixture / "ambiguity_empty.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions.md",
                model_assumptions=fixture / "model_assumptions.md",
                model_plan=plan_path,
            )

        self.assertFalse(result["pass"])
        self.assertTrue(
            any("P0 GRANULARITY_SEMANTIC_CONFLICT" in error for error in result["errors"])
        )

    def test_interpretation_decision_must_propagate_to_model_plan(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2023c-style-regression"
        plan = validator.extract_contract(fixture / "model_plan_valid_final.md", "model_plan")
        plan = copy.deepcopy(plan)
        plan["implemented_interpretation_decisions"]["profit_basis"]["metric"] = "gross_profit"
        with tempfile.TemporaryDirectory() as directory:
            plan_path = self.write_contract(Path(directory), "plan_final.md", plan)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=4,
                stage="final",
                ambiguities=fixture / "ambiguity_empty.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=fixture / "interpretation_decisions.md",
                model_assumptions=fixture / "model_assumptions.md",
                model_plan=plan_path,
            )

        self.assertFalse(result["pass"])
        self.assertIn(
            "profit_basis",
            result["contract_checks"]["model_plan"]["conflicting_interpretation_decisions"],
        )
        self.assertTrue(any("P0 DECISION_NOT_PROPAGATED" in error for error in result["errors"]))

    def test_resolved_ambiguity_can_propagate_through_decision_contract_to_plan(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2023c-style-regression"
        decisions = validator.extract_contract(
            fixture / "interpretation_decisions.md", "interpretation_decisions"
        )
        decisions = copy.deepcopy(decisions)
        decisions["items"][0]["status"] = "RESOLVED_BY_EVIDENCE"
        decision_value = decisions["items"][0]["value"]
        ambiguity = {
            "contract_type": "ambiguity_decisions",
            "schema_version": 1,
            "items": [
                {
                    "id": "profit_basis_review",
                    "kind": "interpretation_ambiguity",
                    "ambiguity_scope": "objective_definition",
                    "question": "题面收益目标采用什么标准化含义？",
                    "impact": ["objective_definition"],
                    "evidence": [
                        {
                            "level": "necessary_deduction",
                            "value": decision_value,
                            "source": "题面收入、成本与损耗字段共同确定净收益构成",
                        }
                    ],
                    "options": [],
                    "recommended": decision_value,
                    "decision": decision_value,
                    "approved_by": None,
                    "freeze_targets": [
                        {
                            "contract": "interpretation_decisions",
                            "id": "profit_basis",
                            "field": "value",
                        }
                    ],
                    "status": "RESOLVED_BY_EVIDENCE",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            ambiguity_path = self.write_contract(root, "ambiguity.md", ambiguity)
            decisions_path = self.write_contract(root, "decisions.md", decisions)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=4,
                stage="final",
                ambiguities=ambiguity_path,
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                interpretation_decisions=decisions_path,
                model_assumptions=fixture / "model_assumptions.md",
                model_plan=fixture / "model_plan_valid_final.md",
            )

        self.assertTrue(result["pass"], result["errors"])
        self.assertEqual(
            result["contract_checks"]["ambiguities"]["decision_not_propagated"], []
        )

    def test_genuine_unresolved_interpretation_ambiguity_blocks_final(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        contract = {
            "contract_type": "ambiguity_decisions",
            "schema_version": 1,
            "items": [
                {
                    "id": "reporting_period",
                    "kind": "interpretation_ambiguity",
                    "ambiguity_scope": "delivery_requirement",
                    "question": "按月还是按季度交付？",
                    "impact": ["data_granularity", "delivery_requirement"],
                    "evidence": [
                        {
                            "level": "attachment_explicit",
                            "value": ["entity", "month"],
                            "source": "附件 A 表头：月份",
                        },
                        {
                            "level": "attachment_explicit",
                            "value": ["entity", "quarter"],
                            "source": "附件 B 模板：季度",
                        },
                    ],
                    "options": [],
                    "recommended": ["entity", "month"],
                    "decision": None,
                    "approved_by": None,
                    "status": "BLOCKING",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            ambiguity_path = self.write_contract(Path(directory), "ambiguity.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=ambiguity_path,
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertFalse(result["pass"])
        self.assertIn("reporting_period", result["contract_checks"]["ambiguities"]["blocking"])
        self.assertTrue(any("P0 FREEZE_GATE_BLOCKED" in error for error in result["errors"]))

    def test_conflicting_problem_and_official_attachment_cannot_be_user_selected(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        contract = {
            "contract_type": "ambiguity_decisions",
            "schema_version": 1,
            "items": [
                {
                    "id": "sales_limit_period",
                    "kind": "interpretation_ambiguity",
                    "ambiguity_scope": "data_granularity",
                    "question": "两个附件口径冲突时采用哪一种？",
                    "impact": ["data_granularity", "hard_constraint"],
                    "evidence": [
                        {
                            "level": "problem_explicit",
                            "value": ["crop", "year", "season"],
                            "source": "题面：按季次",
                        },
                        {
                            "level": "attachment_explicit",
                            "value": ["crop", "year"],
                            "source": "附件 B：按年度",
                        },
                    ],
                    "options": [],
                    "recommended": ["crop", "year", "season"],
                    "decision": ["crop", "year", "season"],
                    "approved_by": "user",
                    "freeze_targets": [
                        {
                            "contract": "granularity_contract",
                            "id": "sales_limit",
                            "field": "dimensions",
                        }
                    ],
                    "status": "APPROVED_BY_USER",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            ambiguity_path = self.write_contract(Path(directory), "ambiguity.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=ambiguity_path,
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertFalse(result["pass"])
        self.assertIn(
            "sales_limit_period",
            result["contract_checks"]["ambiguities"]["official_source_conflicts"],
        )
        self.assertTrue(any("P0 OFFICIAL_SOURCE_CONFLICT" in e for e in result["errors"]))

    def test_compatible_official_sources_and_higher_correction_resolve_by_evidence(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        base = validator.extract_contract(fixture / "ambiguity_resolved.md", "ambiguity_decisions")
        compatible = copy.deepcopy(base)
        compatible["items"][0]["evidence"].append(
            {
                "level": "attachment_explicit",
                "value": ["crop", "year", "season"],
                "source": "official attachment field: season",
            }
        )
        corrected = copy.deepcopy(base)
        corrected["items"][0]["evidence"] = [
            {
                "level": "problem_explicit",
                "value": ["crop", "year"],
                "source": "original problem wording: annual",
            },
            {
                "level": "attachment_explicit",
                "value": ["crop", "year", "season"],
                "source": "official attachment field: season",
            },
            {
                "level": "official_correction",
                "value": ["crop", "year", "season"],
                "source": "official correction: calculate for every season",
            },
        ]

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name, contract in (("compatible", compatible), ("corrected", corrected)):
                with self.subTest(name=name):
                    ambiguity_path = self.write_contract(root, f"{name}.md", contract)
                    result = validator.inspect(
                        fixture / "interpretation_final.md",
                        expected_subproblems=3,
                        stage="final",
                        ambiguities=ambiguity_path,
                        granularity_contract=fixture / "granularity_contract.md",
                        hard_constraints=fixture / "hard_constraints.md",
                        model_plan=fixture / "model_plan_valid_final.md",
                        model_assumptions=fixture / "model_assumptions_empty.md",
                        interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                    )
                    self.assertTrue(result["pass"], result["errors"])
                    self.assertEqual(
                        result["contract_checks"]["ambiguities"]["official_source_conflicts"],
                        [],
                    )

    def test_resolved_decision_must_propagate_to_freeze_target(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        base = validator.extract_contract(fixture / "ambiguity_resolved.md", "ambiguity_decisions")
        missing_target = copy.deepcopy(base)
        del missing_target["items"][0]["freeze_targets"]
        mismatched = copy.deepcopy(base)
        mismatched["items"][0]["evidence"][0]["value"] = ["crop", "year"]
        mismatched["items"][0]["recommended"] = ["crop", "year"]
        mismatched["items"][0]["decision"] = ["crop", "year"]
        self_target = copy.deepcopy(base)
        self_target["items"][0]["freeze_targets"] = [
            {
                "contract": "ambiguity_decisions",
                "id": "sales_limit_period",
                "field": "decision",
            }
        ]

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name, contract in (
                ("missing", missing_target),
                ("mismatched", mismatched),
                ("self_target", self_target),
            ):
                with self.subTest(name=name):
                    ambiguity_path = self.write_contract(root, f"{name}.md", contract)
                    result = validator.inspect(
                        fixture / "interpretation_final.md",
                        expected_subproblems=3,
                        stage="final",
                        ambiguities=ambiguity_path,
                        granularity_contract=fixture / "granularity_contract.md",
                        hard_constraints=fixture / "hard_constraints.md",
                        model_plan=fixture / "model_plan_valid_final.md",
                        model_assumptions=fixture / "model_assumptions_empty.md",
                        interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                    )
                    self.assertFalse(result["pass"])
                    self.assertIn(
                        "sales_limit_period",
                        result["contract_checks"]["ambiguities"]["decision_not_propagated"],
                    )
                    self.assertTrue(
                        any("P0 DECISION_NOT_PROPAGATED" in e for e in result["errors"])
                    )

    def test_verified_cannot_close_a_reviewed_candidate_ambiguity(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        contract = validator.extract_contract(
            fixture / "ambiguity_resolved.md", "ambiguity_decisions"
        )
        contract = copy.deepcopy(contract)
        contract["items"][0]["status"] = "VERIFIED"
        with tempfile.TemporaryDirectory() as directory:
            path = self.write_contract(Path(directory), "verified.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=path,
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertFalse(result["pass"])
        self.assertTrue(
            any("VERIFIED is reserved for facts" in error for error in result["errors"])
        )

    def test_p1_non_blocking_finding_does_not_share_p0_gate(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        granularity = validator.extract_contract(
            fixture / "granularity_contract.md", "granularity_contract"
        )
        granularity = copy.deepcopy(granularity)
        granularity["items"][0]["mutable"] = "YES"
        with tempfile.TemporaryDirectory() as directory:
            path = self.write_contract(Path(directory), "granularity.md", granularity)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=path,
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertTrue(result["pass"], result["errors"])
        finding = next(
            item for item in result["findings"] if item["code"] == "EXPLICIT_GRANULARITY_MUTABLE"
        )
        self.assertEqual(finding["severity"], "P1")
        self.assertEqual(finding["gate"], "NON_BLOCKING")

    def test_model_assumptions_with_sensitivity_do_not_block_final(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        contract = {
            "contract_type": "model_assumptions",
            "schema_version": 1,
            "items": [
                {
                    "id": "cvar_alpha",
                    "parameter": "CVaR confidence level",
                    "source": "model setting; not specified by the problem",
                    "main_value": 0.95,
                    "alternative_values": [0.9, 0.99],
                    "sensitivity": "compare feasibility, objective value, and key decisions",
                    "status": "MODEL_ASSUMPTION",
                },
                {
                    "id": "elasticity_strength",
                    "parameter": "elasticity strength",
                    "source": "estimated/model setting",
                    "main_value": 0.2,
                    "alternative_values": [0.1, 0.3],
                    "sensitivity": "re-estimate Q3 under both alternatives",
                    "status": "MODEL_ASSUMPTION",
                },
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            assumptions = self.write_contract(Path(directory), "assumptions.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=assumptions,
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertTrue(result["pass"], result["errors"])
        self.assertEqual(result["contract_checks"]["model_assumptions"]["count"], 2)
        self.assertFalse(result["contract_checks"]["model_assumptions"]["blocking"])

    def test_structural_assumption_can_use_diagnostic_without_numeric_alternatives(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        contract = {
            "contract_type": "model_assumptions",
            "schema_version": 1,
            "items": [
                {
                    "id": "independent_errors",
                    "statement": "errors are independent across entities",
                    "source": "model structure assumption; not specified by the problem",
                    "diagnostic": "inspect grouped residual correlations",
                    "failure_condition": "stable within-group residual correlation is detected",
                    "fallback_model": "use clustered errors or a correlated-error model",
                    "status": "MODEL_ASSUMPTION",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            assumptions = self.write_contract(Path(directory), "assumptions.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=assumptions,
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertTrue(result["pass"], result["errors"])

    def test_model_assumption_without_challenge_path_blocks_final(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        contract = {
            "contract_type": "model_assumptions",
            "schema_version": 1,
            "items": [
                {
                    "id": "stationarity",
                    "statement": "the process is stationary",
                    "source": "model structure assumption; not specified by the problem",
                    "status": "MODEL_ASSUMPTION",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            assumptions = self.write_contract(Path(directory), "assumptions.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=assumptions,
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertFalse(result["pass"])
        self.assertTrue(
            any("at least one validation/challenge path is required" in e for e in result["errors"])
        )

    def test_model_assumption_cannot_be_stored_as_ambiguity(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        contract = {
            "contract_type": "ambiguity_decisions",
            "schema_version": 1,
            "items": [
                {
                    "id": "cvar_alpha",
                    "kind": "model_assumption",
                    "question": "CVaR alpha",
                    "impact": ["result"],
                    "evidence": [
                        {
                            "level": "testable_assumption",
                            "value": 0.95,
                            "source": "model setting",
                        }
                    ],
                    "decision": 0.95,
                    "status": "MODEL_ASSUMPTION",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            ambiguity_path = self.write_contract(Path(directory), "ambiguity.md", contract)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=ambiguity_path,
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertFalse(result["pass"])
        self.assertTrue(any("MODEL_ASSUMPTION is not an ambiguity status" in e for e in result["errors"]))

    def test_missing_frozen_hard_constraint_triggers_p0(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        hard = validator.extract_contract(fixture / "hard_constraints.md", "hard_constraints")
        plan = validator.extract_contract(fixture / "model_plan_valid_final.md", "model_plan")
        hard = copy.deepcopy(hard)
        plan = copy.deepcopy(plan)
        hard["items"] = [
            {
                "id": f"H-0{number}",
                "statement": f"hard constraint {number}",
                "type": "HARD",
                "evidence_level": "problem_explicit",
                "evidence_ref": f"problem statement line {number}",
                "granularity_ids": ["sales_limit"],
                "status": "VERIFIED",
            }
            for number in range(1, 4)
        ]
        plan["implemented_hard_constraints"] = ["H-01", "H-02"]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            hard_path = self.write_contract(root, "hard.md", hard)
            plan_path = self.write_contract(root, "plan_final.md", plan)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=hard_path,
                model_plan=plan_path,
                model_assumptions=fixture / "model_assumptions_empty.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertFalse(result["pass"])
        self.assertTrue(
            any("P0 HARD_CONSTRAINT_NOT_IMPLEMENTED: H-03" in error for error in result["errors"])
        )

    def test_contract_schema_errors_block_freeze(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        ambiguity = validator.extract_contract(
            fixture / "ambiguity_resolved.md", "ambiguity_decisions"
        )
        granularity = validator.extract_contract(
            fixture / "granularity_contract.md", "granularity_contract"
        )

        cases = []

        duplicate_id = copy.deepcopy(granularity)
        duplicate_id["items"].append(copy.deepcopy(duplicate_id["items"][0]))
        cases.append(("duplicate_id", "granularity", duplicate_id))

        empty_dimensions = copy.deepcopy(granularity)
        empty_dimensions["items"][0]["dimensions"] = []
        cases.append(("empty_dimensions", "granularity", empty_dimensions))

        missing_source = copy.deepcopy(ambiguity)
        del missing_source["items"][0]["evidence"][0]["source"]
        cases.append(("missing_source", "ambiguity", missing_source))

        invalid_mutable = copy.deepcopy(granularity)
        invalid_mutable["items"][0]["mutable"] = "MAYBE"
        cases.append(("invalid_mutable", "granularity", invalid_mutable))

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name, target, contract in cases:
                with self.subTest(name=name):
                    bad_path = self.write_contract(root, f"{name}.md", contract)
                    kwargs = {
                        "ambiguities": fixture / "ambiguity_resolved.md",
                        "granularity_contract": fixture / "granularity_contract.md",
                    }
                    kwargs["ambiguities" if target == "ambiguity" else "granularity_contract"] = bad_path
                    result = validator.inspect(
                        fixture / "interpretation_final.md",
                        expected_subproblems=3,
                        stage="final",
                        hard_constraints=fixture / "hard_constraints.md",
                        model_plan=fixture / "model_plan_valid_final.md",
                        model_assumptions=fixture / "model_assumptions_empty.md",
                        interpretation_decisions=fixture / "interpretation_decisions_empty.md",
                        **kwargs,
                    )
                    self.assertFalse(result["pass"])
                    self.assertTrue(
                        any("P0 CONTRACT_SCHEMA_ERROR" in error for error in result["errors"]),
                        result["errors"],
                    )

    def test_every_contract_requires_schema_version(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        paths = {
            "ambiguities": (fixture / "ambiguity_resolved.md", "ambiguity_decisions"),
            "granularity_contract": (
                fixture / "granularity_contract.md",
                "granularity_contract",
            ),
            "hard_constraints": (fixture / "hard_constraints.md", "hard_constraints"),
            "interpretation_decisions": (
                fixture / "interpretation_decisions_empty.md",
                "interpretation_decisions",
            ),
            "model_assumptions": (
                fixture / "model_assumptions_empty.md",
                "model_assumptions",
            ),
            "model_plan": (fixture / "model_plan_valid_final.md", "model_plan"),
        }
        base_kwargs = {key: value[0] for key, value in paths.items()}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for key, (path, contract_type) in paths.items():
                with self.subTest(contract=key):
                    contract = copy.deepcopy(validator.extract_contract(path, contract_type))
                    del contract["schema_version"]
                    bad_path = self.write_contract(root, f"{key}.md", contract)
                    kwargs = dict(base_kwargs)
                    kwargs[key] = bad_path
                    result = validator.inspect(
                        fixture / "interpretation_final.md",
                        expected_subproblems=3,
                        stage="final",
                        **kwargs,
                    )
                    self.assertFalse(result["pass"])
                    self.assertTrue(
                        any(
                            "P0 CONTRACT_SCHEMA_ERROR" in error
                            and "schema_version" in error
                            for error in result["errors"]
                        ),
                        result["errors"],
                    )

    def test_semantic_contract_fields_are_required(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        granularity = validator.extract_contract(
            fixture / "granularity_contract.md", "granularity_contract"
        )
        hard = validator.extract_contract(fixture / "hard_constraints.md", "hard_constraints")
        plan = validator.extract_contract(fixture / "model_plan_valid_final.md", "model_plan")

        cases = []
        missing_object = copy.deepcopy(granularity)
        del missing_object["items"][0]["object"]
        cases.append(("missing_object", "granularity_contract", missing_object))

        missing_granularity_role = copy.deepcopy(granularity)
        del missing_granularity_role["items"][0]["semantic_role"]
        cases.append(("missing_granularity_role", "granularity_contract", missing_granularity_role))

        missing_statement = copy.deepcopy(hard)
        del missing_statement["items"][0]["statement"]
        cases.append(("missing_statement", "hard_constraints", missing_statement))

        missing_used_by = copy.deepcopy(plan)
        del missing_used_by["items"][0]["used_by"]
        cases.append(("missing_used_by", "model_plan", missing_used_by))

        missing_plan_role = copy.deepcopy(plan)
        del missing_plan_role["items"][0]["semantic_role"]
        cases.append(("missing_plan_role", "model_plan", missing_plan_role))

        missing_actual_dimensions = copy.deepcopy(plan)
        missing_actual_dimensions["items"][0]["dimensions"] = []
        cases.append(("missing_dimensions", "model_plan", missing_actual_dimensions))

        missing_symbol_reason = copy.deepcopy(plan)
        del missing_symbol_reason["items"][0]["symbol"]
        cases.append(("missing_symbol_reason", "model_plan", missing_symbol_reason))

        missing_decision_map = copy.deepcopy(plan)
        del missing_decision_map["implemented_interpretation_decisions"]
        cases.append(("missing_decision_map", "model_plan", missing_decision_map))

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name, target, contract in cases:
                with self.subTest(name=name):
                    path = self.write_contract(root, f"{name}.md", contract)
                    kwargs = {
                        "ambiguities": fixture / "ambiguity_resolved.md",
                        "granularity_contract": fixture / "granularity_contract.md",
                        "hard_constraints": fixture / "hard_constraints.md",
                        "interpretation_decisions": fixture / "interpretation_decisions_empty.md",
                        "model_plan": fixture / "model_plan_valid_final.md",
                        "model_assumptions": fixture / "model_assumptions_empty.md",
                    }
                    kwargs[target] = path
                    result = validator.inspect(
                        fixture / "interpretation_final.md",
                        expected_subproblems=3,
                        stage="final",
                        **kwargs,
                    )
                    self.assertFalse(result["pass"])
                    self.assertTrue(
                        any("P0 CONTRACT_SCHEMA_ERROR" in error for error in result["errors"]),
                        result["errors"],
                    )

    def test_model_plan_null_reason_is_valid_when_symbol_does_not_apply(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        plan = validator.extract_contract(fixture / "model_plan_valid_final.md", "model_plan")
        plan = copy.deepcopy(plan)
        del plan["items"][0]["symbol"]
        plan["items"][0]["null_reason"] = "implemented as an indexed decision rule"
        with tempfile.TemporaryDirectory() as directory:
            path = self.write_contract(Path(directory), "plan_final.md", plan)
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=fixture / "ambiguity_resolved.md",
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=path,
                model_assumptions=fixture / "model_assumptions_empty.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertTrue(result["pass"], result["errors"])

    def test_invalid_contract_json_blocks_freeze(self):
        fixture = SKILL_ROOT / "tests" / "fixtures" / "2024c-regression"
        with tempfile.TemporaryDirectory() as directory:
            bad_path = Path(directory) / "bad.md"
            bad_path.write_text(
                '```contract-json\n{"contract_type": "ambiguity_decisions", "items": [}\n```\n',
                encoding="utf-8",
            )
            result = validator.inspect(
                fixture / "interpretation_final.md",
                expected_subproblems=3,
                stage="final",
                ambiguities=bad_path,
                granularity_contract=fixture / "granularity_contract.md",
                hard_constraints=fixture / "hard_constraints.md",
                model_plan=fixture / "model_plan_valid_final.md",
                model_assumptions=fixture / "model_assumptions_empty.md",
                interpretation_decisions=fixture / "interpretation_decisions_empty.md",
            )

        self.assertFalse(result["pass"])
        self.assertTrue(any("P0 CONTRACT_SCHEMA_ERROR" in error for error in result["errors"]))


if __name__ == "__main__":
    unittest.main()
